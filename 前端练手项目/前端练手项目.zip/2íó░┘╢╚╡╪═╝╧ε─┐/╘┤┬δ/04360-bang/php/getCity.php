<?php

    $con=file_get_contents('http://bang.360.cn/aj/getcitycode');
    echo $con;

?>